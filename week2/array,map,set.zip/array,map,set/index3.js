let grades = [90,98,78,99]
let studentGrades = Array.from(grades, g=> g * 110);
console.log(studentGrades.length)
console.log(studentGrades)
console.log('-------------')
 


