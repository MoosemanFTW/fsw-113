let studentArray = Array(10)
console.log(studentArray.length)
console.log(studentArray)
console.log('-------------')

