let studentArray1 = Array.of(10)
console.log(studentArray1.length)
console.log(studentArray1)
console.log('-------------')
 



